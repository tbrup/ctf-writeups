use std::{error::Error, io};

use rand::rngs::ThreadRng;
use rsa::{
    internals, BigUint, PaddingScheme, PublicKey, PublicKeyParts, RsaPrivateKey, RsaPublicKey,
};

fn input() -> String {
    let mut v = String::new();
    io::stdin().read_line(&mut v).unwrap();
    match v.strip_suffix("\n") {
        Some(s) => s.to_string(),
        None => v,
    }
}

const KEYSIZE: usize = 768;
const HB_COUNT: usize = (KEYSIZE / 64) / 4 * 3;

static mut PRIV_KEY: Option<RsaPrivateKey> = None;
static mut PUB_KEY: Option<RsaPublicKey> = None;

#[no_mangle]
pub extern "C" fn encrypt() {
    let mut rng = rand::thread_rng();
    let pub_key = unsafe { PUB_KEY.as_mut().unwrap() };

    let in_str = input();
    let bytes = in_str.as_bytes();
    let enc_data = pub_key
        .encrypt(&mut rng, PaddingScheme::new_pkcs1v15_encrypt(), &bytes[..])
        .expect("failed to encrypt");

    println!("{}", hex::encode(enc_data));
}

fn calc_block(us: &[u32]) -> u64 {
    let mut s1 = 0u64;
    let mut s2 = 0u64;
    for v in us {
        let v = *v as u64;
        s1 = (s1 + v) & 0xffff_ffff;
        s2 = (s2 + s1) & 0xffff_ffff;
    }
    return (s2 << 32) | s1;
}

fn hash(msg: Vec<u8>) -> Vec<u8> {
    let mut segs = Vec::with_capacity(HB_COUNT);
    for _ in 0..HB_COUNT {
        segs.push(Vec::new());
    }
    for (i, b) in msg.iter().enumerate() {
        segs.get_mut(i % HB_COUNT).unwrap().push(*b);
    }
    let mut digest = Vec::with_capacity(HB_COUNT * 8);
    for mut seg in segs {
        let m = seg.len() % 4;
        if m != 0 {
            seg.extend(vec![0u8; 4 - m]);
        }
        let seg = seg
            .chunks(4)
            .map(|d| u32::from_le_bytes(d.try_into().unwrap()))
            .collect::<Vec<_>>();
        digest.extend(calc_block(&seg).to_le_bytes());
    }
    digest
}

#[no_mangle]
pub extern "C" fn sign() {
    let priv_key = unsafe { PRIV_KEY.as_mut().unwrap() };

    let bytes = hex::decode(input()).expect("failed to decode");
    let sig: Result<_, Box<dyn Error>> = (|| {
        let hashed = hash(bytes);

        let ciphertext = hashed;
        let pad_size = priv_key.size();

        let c = BigUint::from_bytes_be(&ciphertext);
        let m = internals::decrypt::<ThreadRng>(None, priv_key, &c)?;
        let m_bytes = m.to_bytes_be();
        let plaintext = internals::left_pad(&m_bytes, pad_size);

        Ok(plaintext)
    })();
    match sig {
        Ok(enc_data) => println!("{}", hex::encode(enc_data)),
        Err(err) => println!("err: {}", err),
    }
}

fn main() {
    let mut rng = rand::thread_rng();
    let mut priv_key = RsaPrivateKey::new(&mut rng, KEYSIZE).expect("failed to generate a key");
    let pub_key = RsaPublicKey::from(&priv_key);

    if let Err(e) = priv_key.precompute() {
        panic!("failed to precompute for crt: {}", e);
    }

    println!("modulus: n = 0x{}", priv_key.n().to_str_radix(16));
    println!("exponent: e = 0x{}", priv_key.e().to_str_radix(16));
    println!(
        "prime: p = 0x{}...",
        &priv_key.primes()[0].clone().to_str_radix(16)[..40]
    );

    unsafe {
        PRIV_KEY = Some(priv_key);
        PUB_KEY = Some(pub_key);
    }
}
