use std::net::TcpListener;
use std::net::TcpStream;
use std::{
    error::Error,
    io::{BufRead, BufReader, Write},
    sync::Arc,
};
use threadpool::ThreadPool;
use wasmer::{
    wasmparser::Operator, AsStoreMut, CompilerConfig, Cranelift, Instance, Module, Store,
};
use wasmer_middlewares::{
    metering::{self, MeteringPoints},
    Metering,
};
use wasmer_wasi::{WasiBidirectionalSharedPipePair, WasiState};

fn write_energy(
    stream: &mut TcpStream,
    ctx: &mut impl AsStoreMut,
    instance: &Instance,
) -> Result<(), std::io::Error> {
    match metering::get_remaining_points(ctx, &instance) {
        MeteringPoints::Remaining(p) => writeln!(
            stream,
            "Santa has {} energy remaining. Don't over-tax santa",
            p
        ),
        MeteringPoints::Exhausted => {
            writeln!(stream, "Santa died due to exhaustion. What have you done?!")
        }
    }
}

fn cost_function(op: &Operator) -> u64 {
    use Operator::*;
    match op {
        // maths is hard and santa finds substractions exhausting
        I64Sub => 0x20,
        _ => 1,
    }
}

fn handle_conn(mut stream: TcpStream, wasm_bytes: &Vec<u8>) -> Result<(), Box<dyn Error>> {
    writeln!(stream, "Welcome to Santas Signing Session")?;
    writeln!(stream, "")?;

    let meter = Arc::new(Metering::new(u64::MAX, cost_function));

    let mut tcp_in = stream.try_clone()?;
    let mut tcp_in = BufReader::new(&mut tcp_in)
        .lines()
        .map(|result| result.unwrap());

    let mut compiler_config = Cranelift::default();
    compiler_config.push_middleware(meter);
    let mut store = Store::new(compiler_config);
    let module = Module::new(&store, wasm_bytes)?;

    let mut input = WasiBidirectionalSharedPipePair::new().with_blocking(false);
    let output = WasiBidirectionalSharedPipePair::new().with_blocking(false);
    let wasi_env = WasiState::new("wasm-server")
        .stdin(Box::new(input.clone()))
        .stdout(Box::new(output.clone()))
        .finalize(&mut store)?;
    let mut out_lines = BufReader::new(output)
        .lines()
        .map(|l| l.unwrap().trim().to_string());

    let imports = wasi_env.import_object(&mut store, &module)?;

    let instance = Instance::new(&mut store, &module, &imports)?;

    let memory = instance.exports.get_memory("memory")?;
    wasi_env.data_mut(&mut store).set_memory(memory.clone());

    let start = instance.exports.get_function("_start")?;
    let encrypt = instance.exports.get_function("encrypt")?;
    let sign = instance.exports.get_function("sign")?;

    start.call(&mut store, &[])?;

    writeln!(stream, "{}", out_lines.next().ok_or("")?)?;
    writeln!(stream, "{}", out_lines.next().ok_or("")?)?;
    writeln!(stream, "{}", out_lines.next().ok_or("")?)?;
    // santa doesn't have all day
    metering::set_remaining_points(&mut store, &instance, 75_000_000_000);
    write_energy(&mut stream, &mut store, &instance)?;

    writeln!(stream, "")?;

    writeln!(
        stream,
        "Do you want an autograph before you pick up your flag? [yN]"
    )?;
    loop {
        {
            let s = tcp_in.next().ok_or("")?;
            if !s.starts_with("y") && !s.starts_with("Y") {
                break;
            }
        }

        writeln!(stream, "What's your name for the autograph?")?;

        // to allow for any special character in your name, you can also send
        // your name as a hex string
        let name = tcp_in.next().ok_or("")?;
        let name = name.trim().as_bytes();
        let name = match hex::decode(name) {
            Ok(v) => v,
            Err(_) => name.to_vec(),
        };
        writeln!(input, "{}", hex::encode(name))?;
        sign.call(&mut store, &[])?;
        writeln!(
            stream,
            "Here is your autograph: {}",
            out_lines.next().ok_or("")?
        )?;
        write_energy(&mut stream, &mut store, &instance)?;
        if match metering::get_remaining_points(&mut store, &instance) {
            // should be sufficent for one more signature
            MeteringPoints::Remaining(p) => p < 11_000_000,
            MeteringPoints::Exhausted => return Err("Santa died".into()),
        } {
            writeln!(
                stream,
                "Santa is running out of energy, so no more autographs"
            )?;
            break;
        }

        writeln!(stream, "Do you want another autograph? [yN]")?;
    }

    // if you get here, santa will make sure to also give you your flag
    metering::set_remaining_points(&mut store, &instance, u64::MAX);

    writeln!(input, "{}", "HVXX{NOT_THE_FLAG}")?;
    encrypt.call(&mut store, &[])?;

    writeln!(
        stream,
        "And here is your flag: {}",
        out_lines.next().ok_or("")?
    )?;

    writeln!(stream, "Have a nice day!")?;

    stream.shutdown(std::net::Shutdown::Both)?;

    Ok(())
}

fn main() -> Result<(), Box<dyn Error>> {
    let wasm_bytes = std::fs::read("./santa.wasm")?;

    let listener = TcpListener::bind("0.0.0.0:5825")?;
    let pool = ThreadPool::new(6);
    for stream in listener.incoming() {
        let wasm_bytes = wasm_bytes.clone();
        pool.execute(move || {
            let stream = stream.unwrap();
            let _ = handle_conn(stream, &wasm_bytes);
        });
    }

    Ok(())
}
